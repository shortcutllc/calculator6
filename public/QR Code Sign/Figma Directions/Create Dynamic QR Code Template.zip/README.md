
  # Create Dynamic Template

  This is a code bundle for Create Dynamic Template. The original project is available at https://www.figma.com/design/w83LXbYtnEz2NNKYyh3sp8/Create-Dynamic-Template.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  